package com.tony.clientes.trainingAlgaWorks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainingAlgaWorksApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainingAlgaWorksApplication.class, args);
	}

}
