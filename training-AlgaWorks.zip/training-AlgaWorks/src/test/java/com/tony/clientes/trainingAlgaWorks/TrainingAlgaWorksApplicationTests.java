package com.tony.clientes.trainingAlgaWorks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainingAlgaWorksApplicationTests {

	@Test
	void contextLoads() {
	}

}
